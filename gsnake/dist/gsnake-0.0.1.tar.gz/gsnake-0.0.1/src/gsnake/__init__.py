from .main import main,copyright
from .config import *